﻿import { Injectable } from '@angular/core';
import { IBaseEntity } from '../../index.interfaces';

export class Course implements IBaseEntity {
    public CourseId: number;
    //public CertAgency: string;
    public CertificationDescription: string;
    public CertificationSubDescription: string;
    public CourseDescription: string;
    public CourseLength: number;
    public CourseLengthUnit: string;    
    public RenewalPeriodMonths: number;
    public RemoveFromSearch: boolean;
    public PocketCards: boolean;
    //    
    public CertificationAgencyId: number;
    public CourseCategoryId: number;

    // implement BaseEntity
    CreatedBy?: string;
    CreatedOn?: Date;
    ModifiedBy?: string;
    ModifiedOn?: Date;

    constructor() {
        this.CourseId = 0;
        //this.CertAgency: string;
        this.CertificationDescription = null;
        this.CertificationSubDescription = null;
        this.CourseDescription = null;
        this.CourseLength = null;
        this.CourseLengthUnit = null;
        this.RenewalPeriodMonths = null;
        this.RemoveFromSearch = false;
        this.PocketCards = true;
        //
        this.CertificationAgencyId = null;
        this.CourseCategoryId = null;   
    }
}









