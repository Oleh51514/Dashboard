import { Employee } from '../entities/employee.model'

export class GridSearch {
    public Items: Employee[];
    public TotalItems: number;
}