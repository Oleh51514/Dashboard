export var AuthUser = (function () {
    function AuthUser(username, token) {
        if (username === void 0) { username = "unauthorized user"; }
        if (token === void 0) { token = "testTokenText"; }
        this.username = username;
        this.token = token;
        this.refreshToken = "";
        this.useRefreshTokens = false;
    }
    return AuthUser;
}());
//# sourceMappingURL=auth-user.model.js.map