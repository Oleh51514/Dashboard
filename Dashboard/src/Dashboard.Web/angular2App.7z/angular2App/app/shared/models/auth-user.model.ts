export class AuthUser {
    public id: string;
    public username: string;
    public email: string;
    public roles: string[];
    public token: string;

    // not used
    refreshToken: string;
    useRefreshTokens: boolean;

    constructor(username: string = "unauthorized user", token: string = "testTokenText") {        
        this.username = username;        
        this.token = token;

        this.refreshToken = "";
        this.useRefreshTokens = false;
    }
}