// external import
import { Injectable } from "@angular/core";
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Observable } from "rxjs/Observable";
import "rxjs/add/observable/of";
import "rxjs/add/operator/do";
import "rxjs/add/operator/delay";
import "rxjs/add/operator/map";

// app`s import
import { AuthUser } from "../models/auth-user.model";
import { appConstant } from "../constants/app.constant";

@Injectable()
export class AuthService {
    public isLoggedIn: boolean = false;
    public redirectUrl: string;  // store the URL so we can redirect after logging in
    public token: string;
    public currentUser: AuthUser;

    constructor(private http: Http) {
        // set token if saved in local storage
        this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
        this.isLoggedIn = this.currentUser ? true : false;
        this.token = this.currentUser && this.currentUser.token;
    }

    login(
        username: any,
        password: any): Observable<boolean> {
        let requestPath = appConstant.baseUrl + appConstant.authPath;
        //let body = JSON.stringify({ username: username, password: password, grant_type: "password" });
        let body = "username=" + username + "&password=" + password + "&grant_type=password";
        let headers = new Headers({
            //'Accept': "application/json",
            'Content-Type': "application/x-www-form-urlencoded"
        });
        let options = new RequestOptions({ headers: headers });

        return this.http.post(requestPath, body, options)
            .map((response: Response) => {
                // login successful if there's a jwt token in the response
                let token = response.json() && response.json();
                if (token) {
                    // set token property
                    this.token = token;
                    let respObj = response.json();
                    let currentUser = new AuthUser(respObj.userName, respObj.token);
                    currentUser.username = "ALICE"

                    // store AuthUser object in local storage to keep user logged in between page refreshes
                    localStorage.setItem('currentUser', JSON.stringify(currentUser));
                    this.isLoggedIn = true;

                    // return true to indicate successful login
                    return true;
                } else {
                    // return false to indicate failed login
                    return false;
                }
            });
    }

    logout() {
        // clear token remove user from local storage to log user out
        this.token = null;
        localStorage.removeItem('currentUser');
        this.isLoggedIn = false;
    }
}

