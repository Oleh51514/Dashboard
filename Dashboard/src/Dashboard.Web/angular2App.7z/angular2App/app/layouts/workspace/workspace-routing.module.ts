﻿import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { WorkspaceComponent } from './workspace.component';

@NgModule({
    imports: [
        RouterModule.forChild([
            {
                path: '',
                component: WorkspaceComponent,
                // children: [
                //     {
                //         path: 'admin',
                //         loadChildren: '../../modules/admin/admin.module#AdminModule'
                //     },
                //     {
                //         path: 'dashboard',
                //         loadChildren: '../../modules/dashboard/dashboard.module#DashboardModule'
                //     },
                //     {
                //         path: 'employee',
                //         loadChildren: '../../modules/employee/employee.module#EmployeeModule'
                //     },
                //     {
                //         path: 'home',
                //         loadChildren: '../../modules/home/home.module#HomeModule'
                //     },
                //     {
                //         path: 'query',
                //         loadChildren: '../../modules/query/query.module#QueryModule'
                //     },
                //     {
                //         path: 'request',
                //         loadChildren: '../../modules/request/request.module#RequestModule'
                //     },
                //     {
                //         path: 'training',
                //         loadChildren: '../../modules/training/training.module#TrainingModule'
                //     },
                //     {
                //         path: 'course',
                //         loadChildren: '../../modules/course/course.module#CourseModule'
                //     },
                //     {
                //         path: 'instructor',
                //         loadChildren: '../../modules/instructor/instructor.module#InstructorModule'
                //     },
                //     {
                //         path: 'medical',
                //         loadChildren: '../../modules/medical/medical.module#MedicalModule'
                //     }
                // ]
            }
        ])
    ],
    exports: [
        RouterModule
    ]
})
export class WorkspaceRoutingModule {
}


