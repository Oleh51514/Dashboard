﻿export class InstructorCompany {    
    InstructorCompanyId: number;
    InstructorCompanyName: string;
    RemoveFromSearch: boolean;   

    constructor() {
        this.InstructorCompanyId = 0;
        this.InstructorCompanyName = "";
        this.RemoveFromSearch = false;
    }
}
