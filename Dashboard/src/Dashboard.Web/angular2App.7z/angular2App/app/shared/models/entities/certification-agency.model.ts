﻿import { Injectable } from '@angular/core';
import { IBaseEntity } from '../../index.interfaces';

export class CertificationAgency implements IBaseEntity {
    public CertificationAgencyId: number;
    public Agency: string;
    public RemoveFromSearch: boolean;

    // implement BaseEntity
    CreatedBy?: string;
    CreatedOn?: Date;
    ModifiedBy?: string;
    ModifiedOn?: Date;
}