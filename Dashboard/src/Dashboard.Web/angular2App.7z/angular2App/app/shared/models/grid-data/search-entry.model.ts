﻿export class SearchData {
    //currentPage: number;
    Page: number;
    Rows: number;
    Search: string;
    Sidx: string;
    Sord: string;
    OrderBy: string;
    SearchColumns: string[];
    FilterColumns: {};
    ProhibitionColumns: Object[];
    DateRangeFilters: Object[];

    // init
    constructor() {
        this.FilterColumns = {};
        this.SearchColumns = new Array<string>();
    }
}