﻿export interface IBaseEntity {
    CreatedBy?: string;
    CreatedOn?: Date;
    ModifiedBy?: string;
    ModifiedOn?: Date;
}