// external modules
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
// external import
// ...

// app`s modules
// ...
// app`s import
import { AuthGuard, CanDeactivateGuard } from './shared/index.services';

@NgModule({
    imports: [
        RouterModule.forRoot(
            [
                {
                    path: '',
                    redirectTo: '/workspace',
                    pathMatch: "full"
                },
                {
                    path: 'workspace',
                    loadChildren: './layouts/workspace/workspace.module#WorkspaceModule',
                    canLoad: [AuthGuard]
                }
            ])
    ],
    exports: [
        RouterModule
    ],
    providers: [
        CanDeactivateGuard
    ]
})
export class AppRoutingModule { }
