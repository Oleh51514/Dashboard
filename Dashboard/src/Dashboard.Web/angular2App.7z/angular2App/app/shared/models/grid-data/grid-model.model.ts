﻿export class GridModel {
    public items: Array<any>;
    public lazy: boolean;
    public paginator: boolean;
    public rows: number;
    public totalRecords: number;

    constructor() {       
    }
}

