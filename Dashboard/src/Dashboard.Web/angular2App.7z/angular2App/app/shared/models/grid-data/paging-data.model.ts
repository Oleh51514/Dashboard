﻿export class PagingData<T> {
    public Items: Array<T>;
    public TotalItems: number;
}