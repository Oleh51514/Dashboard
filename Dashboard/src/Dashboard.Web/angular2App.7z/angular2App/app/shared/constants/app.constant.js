export var appConstant = {
    baseUrl: "http://localhost:8082/",
    authPath: "identity",
    defaultPath: "/workspace/admin"
};
//# sourceMappingURL=app.constant.js.map