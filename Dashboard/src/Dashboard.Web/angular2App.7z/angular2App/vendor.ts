﻿import '@angular/platform-browser-dynamic';
import '@angular/platform-browser';
import '@angular/core';
import '@angular/http';
import '@angular/router';


// import .js
import 'jquery/src/jquery';
import 'bootstrap/dist/js/bootstrap';

// import .css/.sass
import './css/bootstrap.css';
import './css/bootstrap-theme.css';

