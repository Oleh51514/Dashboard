﻿import {Component} from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
declare var $: any;

@Component({
    templateUrl: 'workspace.component.html'
})
export class WorkspaceComponent {
    
}

