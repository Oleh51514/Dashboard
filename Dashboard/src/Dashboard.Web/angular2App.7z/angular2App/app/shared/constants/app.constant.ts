export const appConstant = {
    baseUrl: "http://localhost:8082/",
    authPath: "identity",
    defaultPath: "/workspace/admin"
};