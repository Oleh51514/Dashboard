﻿import { IBaseEntity } from '../../index.interfaces';

export class Instructor implements IBaseEntity {
    InstructorId: number;
    FirstName: string;
    LastName: string;
    RemoveFromSearch: boolean;
    IsActive: boolean;
    UnionHired: boolean;
    Region: string;    
    //
    public InstructorCompanyId: number;   

    // implement IBaseEntity
    CreatedBy?: string;
    CreatedOn?: Date;
    ModifiedBy?: string;
    ModifiedOn?: Date;

    constructor() {
        this.InstructorId = 0;
        this.FirstName = "";
        this.LastName = "";
        this.RemoveFromSearch = false;
        this.IsActive = false;
        this.UnionHired = false;
        this.Region = "";
    }
}
