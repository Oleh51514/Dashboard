var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Injectable } from "@angular/core";
import { Http, Headers, RequestOptions } from '@angular/http';
import "rxjs/add/observable/of";
import "rxjs/add/operator/do";
import "rxjs/add/operator/delay";
import "rxjs/add/operator/map";
import { AuthUser } from "../models/auth-user.model";
import { appConstant } from "../constants/app.constant";
export var AuthService = (function () {
    function AuthService(http) {
        this.http = http;
        this.isLoggedIn = false;
        this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
        this.isLoggedIn = this.currentUser ? true : false;
        this.token = this.currentUser && this.currentUser.token;
    }
    AuthService.prototype.login = function (username, password) {
        var _this = this;
        var requestPath = appConstant.baseUrl + appConstant.authPath;
        var body = "username=" + username + "&password=" + password + "&grant_type=password";
        var headers = new Headers({
            'Content-Type': "application/x-www-form-urlencoded"
        });
        var options = new RequestOptions({ headers: headers });
        return this.http.post(requestPath, body, options)
            .map(function (response) {
            var token = response.json() && response.json();
            if (token) {
                _this.token = token;
                var respObj = response.json();
                var currentUser = new AuthUser(respObj.userName, respObj.token);
                currentUser.username = "ALICE";
                localStorage.setItem('currentUser', JSON.stringify(currentUser));
                _this.isLoggedIn = true;
                return true;
            }
            else {
                return false;
            }
        });
    };
    AuthService.prototype.logout = function () {
        this.token = null;
        localStorage.removeItem('currentUser');
        this.isLoggedIn = false;
    };
    AuthService = __decorate([
        Injectable(), 
        __metadata('design:paramtypes', [Http])
    ], AuthService);
    return AuthService;
}());
//# sourceMappingURL=auth.service.js.map