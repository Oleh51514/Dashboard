﻿import { Injectable } from '@angular/core';
import { IBaseEntity } from '../../index.interfaces';

export class Employee implements IBaseEntity {
    public EmployeeId: number;
    public LastName: string;
    public FirstName: string;
    public MiddleName: string;
    public Gender: string;
    public Ethnic: string;
    public BirthDate: string;
    public Address: string;
    public City: string
    public Phone: string;
    public Email: string;
    public SSN: string;
    public Title: string;
    public Department: string
    public EmployeeStatus: string;
    public HireDate: Date;
    public RehireDate: Date;
    public Terminated: string;
    public DriversLicense: string;
    public Attachments: string;

    public Diploma: boolean;
    public DepartmentId: number;
    public TerminationDate: Date;
    public EmployeStatusId: number;
    public Deleted: boolean;
    public AccountingId: number;
    public AccountingCreatedOn: Date;
    public AccountingModifiedOn: Date;
    public Occupation: string;
    public FullName: string;

    constructor() {
        this.EmployeeId = 0;
        this.LastName = "";
        this.FirstName = "";
        this.MiddleName = "";
        this.Gender = "";
        this.Ethnic = "";
        this.BirthDate = "";
        this.Address = "";
        this.City = "";
        this.Phone = "";
        this.Email = "";
        this.SSN = "";
        this.Title = "";
        this.Department = "";
        this.EmployeeStatus = "";
        this.HireDate = new Date();
        this.RehireDate = new Date();
        this.Terminated = "";
        this.DriversLicense = "";
        this.Attachments = "";

        this.Diploma = false;
        this.DepartmentId = 0;
        this.TerminationDate = new Date();
        this.EmployeStatusId = 0;
        this.Deleted = false;
        this.AccountingId = 0;
        this.AccountingCreatedOn = new Date();
        this.AccountingModifiedOn = new Date();
        this.Occupation = "";
        this.FullName = "";

        return this;
    }
}