﻿import { IBaseEntity } from '../../index.interfaces';

export class EmployeeMedical implements IBaseEntity {    
    EmployeeMedicalId: number;
    Deleted: boolean;
    Expires: Date;
    Note: string;
    TestDate: Date;
    PdfLocation: string;
    RemoveFromSearch: boolean;
    //
    public EmployeeId: number;
    public MedicalTestId: number;

    // implement IBaseEntity
    CreatedBy?: string;
    CreatedOn?: Date;
    ModifiedBy?: string;
    ModifiedOn?: Date;

    constructor() {
        this.EmployeeMedicalId = 0;
        this.Deleted = false;
        this.Expires = null;
        this.Note = null;
        this.TestDate = null;
        this.PdfLocation = null;
        this.RemoveFromSearch = false;        
    }
}
