﻿import { Injectable } from '@angular/core';
import { IBaseEntity } from '../../index.interfaces';

export class CourseCategory implements IBaseEntity {
    public CourseCategoryId: number;
    public CourseCategoryName: string;
    public RemoveFromSearch: boolean;
    //
    public CompanyId: number;
}